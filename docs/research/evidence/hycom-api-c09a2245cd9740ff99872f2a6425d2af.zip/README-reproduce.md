# EARTHUS experiment c09a2245cd9740ff99872f2a6425d2af

실행: python -m research_runtime.cli replay <이 ZIP 파일>

입력 파일 포함. 모델 의존성은 model/manifest.json에서 확인하세요.
